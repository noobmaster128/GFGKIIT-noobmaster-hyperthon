/*
  # Community Events Platform Schema

  1. New Tables
    - profiles
      - User profiles with username and location
    - events
      - Event details including title, description, location, date
    - event_attendees
      - Junction table for event attendance

  2. Security
    - RLS enabled on all tables
    - Policies for viewing, creating, and updating records
*/

-- Profiles table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS profiles (
    id uuid PRIMARY KEY,
    username text NOT NULL,
    avatar_url text,
    location text,
    created_at timestamptz DEFAULT now(),
    CONSTRAINT fk_user
      FOREIGN KEY (id)
      REFERENCES auth.users (id)
      ON DELETE CASCADE
  );
  
  ALTER TABLE profiles ADD CONSTRAINT username_unique UNIQUE (username);
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Profile security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  CREATE POLICY "Public profiles are viewable by everyone"
    ON profiles FOR SELECT
    USING (true);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Events table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    title text NOT NULL,
    description text NOT NULL,
    location text NOT NULL,
    date timestamptz NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamptz DEFAULT now(),
    max_attendees integer,
    image_url text,
    CONSTRAINT future_date CHECK (date > now()),
    CONSTRAINT fk_creator
      FOREIGN KEY (created_by)
      REFERENCES profiles (id)
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Event security
ALTER TABLE events ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  CREATE POLICY "Events are viewable by everyone"
    ON events FOR SELECT
    USING (true);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Authenticated users can create events"
    ON events FOR INSERT
    WITH CHECK (auth.uid() = created_by);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can update own events"
    ON events FOR UPDATE
    USING (auth.uid() = created_by);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Event attendees table
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS event_attendees (
    event_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamptz DEFAULT now(),
    PRIMARY KEY (event_id, user_id),
    CONSTRAINT fk_event
      FOREIGN KEY (event_id)
      REFERENCES events (id)
      ON DELETE CASCADE,
    CONSTRAINT fk_user
      FOREIGN KEY (user_id)
      REFERENCES profiles (id)
      ON DELETE CASCADE
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Event attendees security
ALTER TABLE event_attendees ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  CREATE POLICY "Attendees are viewable by everyone"
    ON event_attendees FOR SELECT
    USING (true);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can register for events"
    ON event_attendees FOR INSERT
    WITH CHECK (auth.uid() = user_id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE POLICY "Users can remove themselves from events"
    ON event_attendees FOR DELETE
    USING (auth.uid() = user_id);
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;