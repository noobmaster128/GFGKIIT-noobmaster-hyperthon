import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, MapPin } from 'lucide-react';

export default function Home() {
  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Discover Local Events & Build Community
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Join events in your area or create your own. Connect with people who share your interests.
        </p>
        <Link
          to="/events"
          className="bg-indigo-600 text-white px-8 py-3 rounded-md text-lg font-medium hover:bg-indigo-700"
        >
          Explore Events
        </Link>
      </div>

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <Calendar className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Find Events</h3>
          <p className="text-gray-600">
            Discover events happening in your area. Filter by date, category, or location.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <Users className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Host Events</h3>
          <p className="text-gray-600">
            Create and manage your own events. Connect with attendees and build your community.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <MapPin className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Stay Local</h3>
          <p className="text-gray-600">
            Focus on your local community. Find events and people nearby.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=1200&h=400"
          alt="Community event"
          className="w-full h-64 object-cover"
        />
        <div className="p-8">
          <h2 className="text-2xl font-bold mb-4">Why Join EventHub?</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">For Event Organizers</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Easy event creation and management</li>
                <li>Reach your target audience</li>
                <li>Track attendance and engagement</li>
                <li>Build your community</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">For Attendees</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Discover events near you</li>
                <li>Meet like-minded people</li>
                <li>Stay updated with notifications</li>
                <li>Easy registration process</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}