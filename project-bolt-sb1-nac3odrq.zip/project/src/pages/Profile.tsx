import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, MapPin, Users, Edit2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Profile = {
  username: string;
  avatar_url: string | null;
  location: string | null;
};

type Event = {
  id: string;
  title: string;
  description: string;
  location: string;
  date: string;
  image_url: string | null;
  max_attendees: number | null;
};

export default function Profile() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [createdEvents, setCreatedEvents] = useState<Event[]>([]);
  const [attendingEvents, setAttendingEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    location: '',
  });

  useEffect(() => {
    fetchUserData();
  }, []);

  async function fetchUserData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/auth');
        return;
      }

      // Fetch profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profileData) {
        setProfile(profileData);
        setFormData({
          username: profileData.username,
          location: profileData.location || '',
        });
      }

      // Fetch created events
      const { data: createdEventsData } = await supabase
        .from('events')
        .select('*')
        .eq('created_by', user.id)
        .order('date', { ascending: true });

      if (createdEventsData) {
        setCreatedEvents(createdEventsData);
      }

      // Fetch attending events
      const { data: attendingEventsData } = await supabase
        .from('events')
        .select('events.*')
        .join('event_attendees', { 'events.id': 'event_attendees.event_id' })
        .eq('event_attendees.user_id', user.id)
        .order('date', { ascending: true });

      if (attendingEventsData) {
        setAttendingEvents(attendingEventsData);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          username: formData.username,
          location: formData.location || null,
        })
        .eq('id', user.id);

      if (error) throw error;
      
      setProfile(prev => ({
        ...prev!,
        username: formData.username,
        location: formData.location,
      }));
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading profile...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        {editing ? (
          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Save Changes
              </button>
            </div>
          </form>
        ) : (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">{profile?.username}</h2>
              <button
                onClick={() => setEditing(true)}
                className="flex items-center text-gray-600 hover:text-indigo-600"
              >
                <Edit2 className="w-4 h-4 mr-1" />
                Edit Profile
              </button>
            </div>
            {profile?.location && (
              <div className="flex items-center text-gray-600">
                <MapPin className="w-5 h-5 mr-2" />
                {profile.location}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-xl font-semibold mb-4">Your Events</h3>
          <div className="space-y-4">
            {createdEvents.map(event => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold mb-4">Events You're Attending</h3>
          <div className="space-y-4">
            {attendingEvents.map(event => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function EventCard({ event }: { event: Event }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {event.image_url ? (
        <img
          src={event.image_url}
          alt={event.title}
          className="w-full h-32 object-cover"
        />
      ) : (
        <div className="w-full h-32 bg-gray-200 flex items-center justify-center">
          <CalendarIcon className="w-8 h-8 text-gray-400" />
        </div>
      )}
      <div className="p-4">
        <h4 className="font-semibold mb-2">{event.title}</h4>
        <div className="space-y-1 text-sm text-gray-600">
          <div className="flex items-center">
            <CalendarIcon className="w-4 h-4 mr-2" />
            {format(new Date(event.date), 'PPp')}
          </div>
          <div className="flex items-center">
            <MapPin className="w-4 h-4 mr-2" />
            {event.location}
          </div>
          {event.max_attendees && (
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Max {event.max_attendees} attendees
            </div>
          )}
        </div>
      </div>
    </div>
  );
}